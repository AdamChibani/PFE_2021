import { useQuery } from "@apollo/react-hooks";
import gql from "graphql-tag";
import CreateIcon from "@material-ui/icons/Create";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import selectAuth from "../../redux/user/userSelector";
import styles from "./my_profile.module.css";

const GET_COMPANY_QUERY = gql`
  query d($id: Int!) {
    getCompanyByAdmin(id: $id) {
      id
      enterpriseSize
      offices {
        id
        name
        address {
          street
          city
          postalCode
          country {
            id
            name
          }
        }
      }
    }
  }
`;

function MyProfileAdmin(props) {
  const { data, loading } = useQuery(GET_COMPANY_QUERY, {
    variables: { id: props?.user?.user?.id },
  });
  console.log(data);
  return (
    <div className=" col-lg-8 bg-white rounded-4 shadow-9">
      <div className="pr-xl-0 pr-xxl-14 p-5 pl-xs-12 pt-7 pb-5">
        <h4 className="font-size-6 mb-5 mt-5 text-black-2 font-weight-semibold d-flex justify-content-between align-items-center">
          Number of employees
          <CreateIcon
            className={styles["edit"]}
            onClick={() => setEditNum(!editNum)}
          />
        </h4>
        <h5 className="font-size-4 font-weight-semibold mb-0 text-black-2 text-break">
          {data?.getCompanyByAdmin?.enterpriseSize}
        </h5>
      </div>
      <div className="border-top pr-xl-0 pr-xxl-14 p-5 pl-xs-12 pt-7 pb-5"></div>
    </div>
  );
}

const mapStateToProps = createStructuredSelector({ user: selectAuth });

export default connect(mapStateToProps)(MyProfileAdmin);
