export {default} from './Logo'
