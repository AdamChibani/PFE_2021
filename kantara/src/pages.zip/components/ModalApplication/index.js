export { default } from "./ModalApplication";
