export { default } from "./consultantInfo";
