function Images() {
  return <input type="file" placeholder="upload" />;
}
export default Images;
